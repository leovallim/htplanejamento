<?php 
get_header();
get_template_part( 'template-parts/global', 'header' );
ht_content();
get_template_part( 'template-parts/global', 'footer' );
get_footer();