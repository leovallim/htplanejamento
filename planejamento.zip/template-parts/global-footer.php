<div class="wrapper">
    <div class="container" >
        <a href="<?= get_home_url() ?>" class="button"><i class="fa-solid fa-arrow-left"></i> Voltar</a>
    </div>
</div>
<footer class="footer" style="margin-top:50px">
    <span class="footer__text">Desenvolvido por</span>
    <a href="https://htcomunicacao.com.br" target="_blank">
        <img src="<?= get_template_directory_uri() ?>/dist/images/logo-ht-comunicacao-red.png" alt="Logo da HT Comunicação" class="footer__image">
    </a>
</footer>