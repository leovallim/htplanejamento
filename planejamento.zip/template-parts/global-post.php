<main class="site">
    <?php the_content(); ?>
</main>