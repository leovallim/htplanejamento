<?php 
//Silence is gold