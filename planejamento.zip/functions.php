<?php 
require_once( get_template_directory() ."/core/helpers.php");
require_once( get_template_directory() ."/core/setup.php");
require_once( get_template_directory() ."/core/scripts.php");
require_once( get_template_directory() ."/core/option-pages.php");
require_once( get_template_directory() ."/core/actions.php");

