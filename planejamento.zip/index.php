<?php 
get_header();
get_template_part('template-parts/global', 'post');
get_footer();