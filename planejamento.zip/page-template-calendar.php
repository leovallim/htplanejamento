<?php
//Template name: Calendário

get_header( );

get_template_part( 'template-part/calendar', 'main' );

get_footer( );