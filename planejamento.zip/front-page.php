<?php 
wp_redirect(get_field('current_sazonal', 'options'));
exit();