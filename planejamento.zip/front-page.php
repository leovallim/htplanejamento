<?php 
get_header();
ht_content();
get_footer();