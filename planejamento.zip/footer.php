<?php //get_template_part( 'template-parts/footer', null, ht_footer_info() ); ?>
<?php wp_footer(); ?>
</body>
</html>